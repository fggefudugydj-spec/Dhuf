package com.example.core

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.LaunchHistoryEntry
import com.example.model.LaunchMode
import com.example.model.SavedServer
import com.example.model.WorldBackupRecord
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.leviDataStore by preferencesDataStore(name = "levilab_prefs")

class LeviPreferences(private val context: Context) {

    private val languageKey = stringPreferencesKey("app_language")
    private val serversJsonKey = stringPreferencesKey("saved_servers_json")
    private val launchModeKey = stringPreferencesKey("preferred_launch_mode")
    private val autoVerifyCacheKey = booleanPreferencesKey("auto_verify_cache")
    private val preferDirectApkLoadKey = booleanPreferencesKey("prefer_direct_apk_load")
    private val launchHistoryJsonKey = stringPreferencesKey("launch_history_json")
    private val worldBackupsJsonKey = stringPreferencesKey("world_backups_json")
    private val keepScreenOnKey = booleanPreferencesKey("keep_screen_on")
    private val showFloatingGameHudKey = booleanPreferencesKey("show_floating_game_hud")
    private val loadCustomNativeModsKey = booleanPreferencesKey("load_custom_native_mods")
    private val enabledAddonIdsJsonKey = stringPreferencesKey("enabled_addon_ids_json")
    private val enabledModIdsJsonKey = stringPreferencesKey("enabled_mod_ids_json")
    private val allowCustomApplicationKey = booleanPreferencesKey("allow_custom_application")
    private val bootstrapContentProvidersKey = booleanPreferencesKey("bootstrap_content_providers")
    private val strictVaultIsolationKey = booleanPreferencesKey("strict_vault_isolation")
    private val immersiveGameSurfaceKey = booleanPreferencesKey("immersive_game_surface")

    val languageFlow: Flow<AppLanguage> = context.leviDataStore.data.map { prefs ->
        when (prefs[languageKey]) {
            AppLanguage.EN.name -> AppLanguage.EN
            else -> AppLanguage.AR
        }
    }

    val launchModeFlow: Flow<LaunchMode> = context.leviDataStore.data.map { prefs ->
        parseLaunchMode(prefs[launchModeKey])
    }

    val autoVerifyCacheFlow: Flow<Boolean> = context.leviDataStore.data.map { prefs ->
        prefs[autoVerifyCacheKey] ?: true
    }

    val preferDirectApkLoadFlow: Flow<Boolean> = context.leviDataStore.data.map { prefs ->
        prefs[preferDirectApkLoadKey] ?: true
    }

    val keepScreenOnFlow: Flow<Boolean> = context.leviDataStore.data.map { prefs ->
        prefs[keepScreenOnKey] ?: true
    }

    val showFloatingGameHudFlow: Flow<Boolean> = context.leviDataStore.data.map { prefs ->
        prefs[showFloatingGameHudKey] ?: true
    }

    val loadCustomNativeModsFlow: Flow<Boolean> = context.leviDataStore.data.map { prefs ->
        prefs[loadCustomNativeModsKey] ?: false
    }

    val allowCustomApplicationFlow: Flow<Boolean> = context.leviDataStore.data.map { prefs ->
        prefs[allowCustomApplicationKey] ?: true
    }

    val bootstrapContentProvidersFlow: Flow<Boolean> = context.leviDataStore.data.map { prefs ->
        prefs[bootstrapContentProvidersKey] ?: true
    }

    val strictVaultIsolationFlow: Flow<Boolean> = context.leviDataStore.data.map { prefs ->
        prefs[strictVaultIsolationKey] ?: true
    }

    val immersiveGameSurfaceFlow: Flow<Boolean> = context.leviDataStore.data.map { prefs ->
        prefs[immersiveGameSurfaceKey] ?: true
    }

    val enabledAddonIdsFlow: Flow<Set<String>> = context.leviDataStore.data.map { prefs ->
        decodeStringSet(prefs[enabledAddonIdsJsonKey])
    }

    val enabledModIdsFlow: Flow<Set<String>> = context.leviDataStore.data.map { prefs ->
        decodeStringSet(prefs[enabledModIdsJsonKey])
    }

    val savedServersFlow: Flow<List<SavedServer>> = context.leviDataStore.data.map { prefs ->
        decodeServers(prefs[serversJsonKey])
    }

    val launchHistoryFlow: Flow<List<LaunchHistoryEntry>> = context.leviDataStore.data.map { prefs ->
        decodeLaunchHistory(prefs[launchHistoryJsonKey])
    }

    val worldBackupsFlow: Flow<List<WorldBackupRecord>> = context.leviDataStore.data.map { prefs ->
        decodeWorldBackups(prefs[worldBackupsJsonKey])
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.leviDataStore.edit { prefs ->
            prefs[languageKey] = language.name
        }
    }

    suspend fun setLaunchMode(mode: LaunchMode) {
        context.leviDataStore.edit { prefs ->
            prefs[launchModeKey] = mode.name
        }
    }

    suspend fun setAutoVerifyCache(enabled: Boolean) {
        context.leviDataStore.edit { prefs ->
            prefs[autoVerifyCacheKey] = enabled
        }
    }

    suspend fun setPreferDirectApkLoad(enabled: Boolean) {
        context.leviDataStore.edit { prefs ->
            prefs[preferDirectApkLoadKey] = enabled
        }
    }

    suspend fun setKeepScreenOn(enabled: Boolean) {
        context.leviDataStore.edit { prefs ->
            prefs[keepScreenOnKey] = enabled
        }
    }

    suspend fun setShowFloatingGameHud(enabled: Boolean) {
        context.leviDataStore.edit { prefs ->
            prefs[showFloatingGameHudKey] = enabled
        }
    }

    suspend fun setLoadCustomNativeMods(enabled: Boolean) {
        context.leviDataStore.edit { prefs ->
            prefs[loadCustomNativeModsKey] = enabled
        }
    }

    suspend fun setAllowCustomApplication(enabled: Boolean) {
        context.leviDataStore.edit { prefs ->
            prefs[allowCustomApplicationKey] = enabled
        }
    }

    suspend fun setBootstrapContentProviders(enabled: Boolean) {
        context.leviDataStore.edit { prefs ->
            prefs[bootstrapContentProvidersKey] = enabled
        }
    }

    suspend fun setStrictVaultIsolation(enabled: Boolean) {
        context.leviDataStore.edit { prefs ->
            prefs[strictVaultIsolationKey] = enabled
        }
    }

    suspend fun setImmersiveGameSurface(enabled: Boolean) {
        context.leviDataStore.edit { prefs ->
            prefs[immersiveGameSurfaceKey] = enabled
        }
    }

    suspend fun saveEnabledAddonIds(ids: Set<String>) {
        context.leviDataStore.edit { prefs ->
            prefs[enabledAddonIdsJsonKey] = encodeStringSet(ids)
        }
    }

    suspend fun saveEnabledModIds(ids: Set<String>) {
        context.leviDataStore.edit { prefs ->
            prefs[enabledModIdsJsonKey] = encodeStringSet(ids)
        }
    }

    suspend fun saveServers(servers: List<SavedServer>) {
        context.leviDataStore.edit { prefs ->
            prefs[serversJsonKey] = encodeServers(servers)
        }
    }

    suspend fun appendLaunchHistory(entry: LaunchHistoryEntry) {
        context.leviDataStore.edit { prefs ->
            val current = decodeLaunchHistory(prefs[launchHistoryJsonKey])
            val updated = (listOf(entry) + current).take(50)
            prefs[launchHistoryJsonKey] = encodeLaunchHistory(updated)
        }
    }

    suspend fun appendWorldBackupRecord(record: WorldBackupRecord) {
        context.leviDataStore.edit { prefs ->
            val current = decodeWorldBackups(prefs[worldBackupsJsonKey])
            val updated = (listOf(record) + current).take(30)
            prefs[worldBackupsJsonKey] = encodeWorldBackups(updated)
        }
    }

    suspend fun clearLaunchHistory() {
        context.leviDataStore.edit { prefs ->
            prefs.remove(launchHistoryJsonKey)
        }
    }

    private fun encodeStringSet(values: Set<String>): String {
        val array = JSONArray()
        values.forEach { array.put(it) }
        return array.toString()
    }

    private fun decodeStringSet(raw: String?): Set<String> {
        if (raw.isNullOrBlank()) return emptySet()
        return runCatching {
            val array = JSONArray(raw)
            buildSet {
                for (i in 0 until array.length()) {
                    val v = array.optString(i, "")
                    if (v.isNotBlank()) add(v)
                }
            }
        }.getOrDefault(emptySet())
    }

    private fun encodeServers(servers: List<SavedServer>): String {
        val array = JSONArray()
        for (server in servers) {
            val obj = JSONObject()
            obj.put("id", server.id)
            obj.put("label", server.label)
            obj.put("host", server.host)
            obj.put("port", server.port)
            array.put(obj)
        }
        return array.toString()
    }

    private fun decodeServers(raw: String?): List<SavedServer> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val host = obj.optString("host", "").trim()
                    if (host.isNotEmpty()) {
                        add(
                            SavedServer(
                                id = obj.optString("id", "$host:${obj.optInt("port", 19132)}"),
                                label = obj.optString("label", host),
                                host = host,
                                port = obj.optInt("port", 19132)
                            )
                        )
                    }
                }
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun encodeLaunchHistory(entries: List<LaunchHistoryEntry>): String {
        val array = JSONArray()
        for (item in entries) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("timestamp", item.timestamp)
            obj.put("packageName", item.packageName)
            obj.put("versionName", item.versionName)
            obj.put("mode", item.mode.name)
            obj.put("succeeded", item.succeeded)
            obj.put("usedFallback", item.usedFallback)
            obj.put("mainLibLoadSource", item.mainLibLoadSource)
            obj.put("summary", item.summary)
            array.put(obj)
        }
        return array.toString()
    }

    private fun decodeLaunchHistory(raw: String?): List<LaunchHistoryEntry> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val pkg = obj.optString("packageName", "")
                    if (pkg.isNotBlank()) {
                        val mode = parseLaunchMode(obj.optString("mode", LaunchMode.DIRECT_NATIVE.name))
                        add(
                            LaunchHistoryEntry(
                                id = obj.optString("id", i.toString()),
                                timestamp = obj.optString("timestamp", ""),
                                packageName = pkg,
                                versionName = obj.optString("versionName", "unknown"),
                                mode = mode,
                                succeeded = obj.optBoolean("succeeded", false),
                                usedFallback = obj.optBoolean("usedFallback", false),
                                mainLibLoadSource = obj.optString("mainLibLoadSource", "UNKNOWN"),
                                summary = obj.optString("summary", "")
                            )
                        )
                    }
                }
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun encodeWorldBackups(records: List<WorldBackupRecord>): String {
        val array = JSONArray()
        for (item in records) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("timestamp", item.timestamp)
            obj.put("worldName", item.worldName)
            obj.put("fileName", item.fileName)
            obj.put("fileCount", item.fileCount)
            obj.put("totalBytes", item.totalBytes)
            obj.put("sha256Short", item.sha256Short)
            obj.put("hasLevelDat", item.hasLevelDat)
            array.put(obj)
        }
        return array.toString()
    }

    private fun decodeWorldBackups(raw: String?): List<WorldBackupRecord> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val worldName = obj.optString("worldName", "")
                    if (worldName.isNotBlank()) {
                        add(
                            WorldBackupRecord(
                                id = obj.optString("id", i.toString()),
                                timestamp = obj.optString("timestamp", ""),
                                worldName = worldName,
                                fileName = obj.optString("fileName", "world.mcworld"),
                                fileCount = obj.optInt("fileCount", 0),
                                totalBytes = obj.optLong("totalBytes", 0L),
                                sha256Short = obj.optString("sha256Short", "n/a"),
                                hasLevelDat = obj.optBoolean("hasLevelDat", false)
                            )
                        )
                    }
                }
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    companion object {
        fun parseLaunchMode(raw: String?): LaunchMode {
            return when (raw) {
                LaunchMode.QUICK_OFFICIAL.name -> LaunchMode.QUICK_OFFICIAL
                LaunchMode.ADJACENT_SPLIT.name -> LaunchMode.ADJACENT_SPLIT
                LaunchMode.DIRECT_NATIVE.name -> LaunchMode.DIRECT_NATIVE
                else -> LaunchMode.DIRECT_NATIVE
            }
        }
    }
}
