package com.example.tools

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.core.LeviLogger
import com.example.launcher.InProcessApkHostEngine
import com.example.model.AddonPackType
import com.example.model.InstalledAddonItem
import com.example.model.InstalledMinecraftPackage
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipInputStream

object AddonPackManager {

    private const val ADDONS_DIR = "mc_addons"
    private const val META_FILE = ".levilab_addon.json"

    fun addonsRootDir(context: Context): File =
        File(context.filesDir, ADDONS_DIR).apply { mkdirs() }

    fun importAddonArchive(
        context: Context,
        uri: Uri,
        enabledIds: Set<String>,
        logger: LeviLogger? = null
    ): Result<List<InstalledAddonItem>> {
        return runCatching {
            val resolver = context.contentResolver
            val fileName = queryDisplayName(context, uri) ?: "addon.mcpack"
            val stagingDir = File(context.cacheDir, "addon_staging_${UUID.randomUUID()}").apply { mkdirs() }
            try {
                val inputStream = resolver.openInputStream(uri)
                    ?: error("Could not open addon archive: $fileName")

                inputStream.use { raw ->
                    ZipInputStream(BufferedInputStream(raw)).use { zis ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val entry = zis.nextEntry ?: break
                            val segments = WorldBackupManager.sanitizeZipRelativePath(entry.name) ?: continue
                            val outFile = segments.fold(stagingDir) { acc, seg -> File(acc, seg) }
                            if (entry.isDirectory) {
                                outFile.mkdirs()
                            } else {
                                outFile.parentFile?.mkdirs()
                                FileOutputStream(outFile).use { fos ->
                                    while (true) {
                                        val n = zis.read(buf)
                                        if (n <= 0) break
                                        fos.write(buf, 0, n)
                                    }
                                }
                            }
                        }
                    }
                }

                // Handle .mcaddon containers that hold nested .mcpack / .zip files
                val nestedArchives = stagingDir.walkTopDown()
                    .filter { it.isFile && (it.name.endsWith(".mcpack", true) || it.name.endsWith(".zip", true)) }
                    .toList()
                nestedArchives.forEachIndexed { index, archive ->
                    val nestedTarget = File(stagingDir, "nested_pack_${index}_${archive.nameWithoutExtension}")
                    nestedTarget.mkdirs()
                    ZipInputStream(BufferedInputStream(archive.inputStream())).use { nzis ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val entry = nzis.nextEntry ?: break
                            val segments = WorldBackupManager.sanitizeZipRelativePath(entry.name) ?: continue
                            val outFile = segments.fold(nestedTarget) { acc, seg -> File(acc, seg) }
                            if (entry.isDirectory) {
                                outFile.mkdirs()
                            } else {
                                outFile.parentFile?.mkdirs()
                                FileOutputStream(outFile).use { fos ->
                                    while (true) {
                                        val n = nzis.read(buf)
                                        if (n <= 0) break
                                        fos.write(buf, 0, n)
                                    }
                                }
                            }
                        }
                    }
                    archive.delete()
                }

                val manifestFiles = stagingDir.walkTopDown()
                    .filter { it.isFile && it.name.equals("manifest.json", ignoreCase = true) }
                    .toList()

                if (manifestFiles.isEmpty()) {
                    error("No manifest.json found inside $fileName")
                }

                val imported = mutableListOf<InstalledAddonItem>()
                val root = addonsRootDir(context)
                for (manifestFile in manifestFiles) {
                    val packSourceDir = manifestFile.parentFile ?: continue
                    val parsed = parseManifestJson(manifestFile, packSourceDir.name) ?: continue
                    val id = sanitizeId("${parsed.uuid}_${parsed.type.name.lowercase()}")
                    val destDir = File(root, id)
                    if (destDir.exists()) destDir.deleteRecursively()
                    packSourceDir.copyRecursively(destDir, overwrite = true)

                    val sizeBytes = computeDirSize(destDir)
                    val isEnabled = true
                    val item = InstalledAddonItem(
                        id = id,
                        uuid = parsed.uuid,
                        name = parsed.name,
                        description = parsed.description,
                        version = parsed.version,
                        type = parsed.type,
                        minEngineVersion = parsed.minEngineVersion,
                        dirPath = destDir.absolutePath,
                        sizeBytes = sizeBytes,
                        isEnabled = isEnabled
                    )
                    writeMetaFile(destDir, item)
                    imported.add(item)
                }

                if (imported.isEmpty()) {
                    error("Found manifest.json in $fileName, but could not parse valid Bedrock pack header.")
                }

                logger?.success(
                    "ADDON_VAULT",
                    "Imported ${imported.size} pack(s) from $fileName: ${imported.joinToString { "${it.name} [${it.type.name}]" }}"
                )
                imported
            } finally {
                stagingDir.deleteRecursively()
            }
        }.onFailure { err ->
            logger?.error("ADDON_VAULT", "Addon import failed: ${err.message}", err)
        }
    }

    fun loadAllAddons(context: Context, enabledIds: Set<String>): List<InstalledAddonItem> {
        val root = addonsRootDir(context)
        val dirs = root.listFiles { f -> f.isDirectory } ?: return emptyList()
        return dirs.mapNotNull { dir ->
            val metaFile = File(dir, META_FILE)
            val fromMeta = if (metaFile.isFile) {
                runCatching {
                    val json = JSONObject(metaFile.readText(Charsets.UTF_8))
                    InstalledAddonItem(
                        id = json.optString("id", dir.name),
                        uuid = json.optString("uuid", ""),
                        name = json.optString("name", dir.name),
                        description = json.optString("description", ""),
                        version = json.optString("version", "1.0.0"),
                        type = runCatching {
                            AddonPackType.valueOf(json.optString("type", AddonPackType.UNKNOWN.name))
                        }.getOrDefault(AddonPackType.UNKNOWN),
                        minEngineVersion = json.optString("minEngineVersion", ""),
                        dirPath = dir.absolutePath,
                        sizeBytes = json.optLong("sizeBytes", computeDirSize(dir)),
                        isEnabled = dir.name in enabledIds || json.optString("id", dir.name) in enabledIds
                    )
                }.getOrNull()
            } else null

            fromMeta ?: run {
                val manifest = File(dir, "manifest.json")
                if (!manifest.isFile) return@mapNotNull null
                val parsed = parseManifestJson(manifest, dir.name) ?: return@mapNotNull null
                InstalledAddonItem(
                    id = dir.name,
                    uuid = parsed.uuid,
                    name = parsed.name,
                    description = parsed.description,
                    version = parsed.version,
                    type = parsed.type,
                    minEngineVersion = parsed.minEngineVersion,
                    dirPath = dir.absolutePath,
                    sizeBytes = computeDirSize(dir),
                    isEnabled = dir.name in enabledIds
                )
            }
        }.sortedBy { it.name.lowercase() }
    }

    fun deleteAddon(context: Context, addonId: String, logger: LeviLogger? = null): Boolean {
        val dir = File(addonsRootDir(context), addonId)
        val ok = dir.exists() && dir.deleteRecursively()
        if (ok) {
            logger?.info("ADDON_VAULT", "Removed addon $addonId")
        }
        return ok
    }

    fun syncEnabledAddonsToSandbox(
        context: Context,
        pkg: InstalledMinecraftPackage,
        addons: List<InstalledAddonItem>,
        logger: LeviLogger? = null
    ): Result<Int> {
        return runCatching {
            val profileKey = InProcessApkHostEngine.buildProfileKey(pkg)
            val sandboxBase = context.getExternalFilesDir(null)
                ?.let { File(it, "mc_sandbox/$profileKey/files/games/com.mojang") }
                ?: File(context.filesDir, "mc_sandbox/$profileKey/files/games/com.mojang")
            val rpDir = File(sandboxBase, "resource_packs").apply { mkdirs() }
            val bpDir = File(sandboxBase, "behavior_packs").apply { mkdirs() }
            val mcpeDir = File(sandboxBase, "minecraftpe").apply { mkdirs() }

            val enabled = addons.filter { it.isEnabled }
            val rpEntries = JSONArray()
            val bpEntries = JSONArray()
            var syncedCount = 0

            for (addon in enabled) {
                val src = File(addon.dirPath)
                if (!src.isDirectory) continue
                when (addon.type) {
                    AddonPackType.RESOURCE_PACK, AddonPackType.SKIN_PACK -> {
                        val dest = File(rpDir, addon.id)
                        if (dest.exists()) dest.deleteRecursively()
                        src.copyRecursively(dest, overwrite = true)
                        File(dest, META_FILE).delete()
                        if (addon.uuid.isNotBlank() && addon.type == AddonPackType.RESOURCE_PACK) {
                            rpEntries.put(buildGlobalPackJson(addon.uuid, addon.version))
                        }
                        syncedCount++
                    }
                    AddonPackType.BEHAVIOR_PACK -> {
                        val dest = File(bpDir, addon.id)
                        if (dest.exists()) dest.deleteRecursively()
                        src.copyRecursively(dest, overwrite = true)
                        File(dest, META_FILE).delete()
                        if (addon.uuid.isNotBlank()) {
                            bpEntries.put(buildGlobalPackJson(addon.uuid, addon.version))
                        }
                        syncedCount++
                    }
                    else -> {
                        val dest = File(rpDir, addon.id)
                        if (dest.exists()) dest.deleteRecursively()
                        src.copyRecursively(dest, overwrite = true)
                        File(dest, META_FILE).delete()
                        syncedCount++
                    }
                }
            }

            File(mcpeDir, "global_resource_packs.json").writeText(rpEntries.toString(2), Charsets.UTF_8)
            File(mcpeDir, "global_behavior_packs.json").writeText(bpEntries.toString(2), Charsets.UTF_8)

            logger?.success(
                "ADDON_VAULT",
                "Synced $syncedCount enabled pack(s) into sandbox ${sandboxBase.absolutePath}"
            )
            syncedCount
        }.onFailure { err ->
            logger?.error("ADDON_VAULT", "Failed syncing packs to sandbox: ${err.message}", err)
        }
    }

    private data class ParsedManifest(
        val uuid: String,
        val name: String,
        val description: String,
        val version: String,
        val minEngineVersion: String,
        val type: AddonPackType
    )

    private fun parseManifestJson(file: File, fallbackName: String): ParsedManifest? {
        return runCatching {
            val cleanJson = stripJsonComments(file.readText(Charsets.UTF_8))
            val root = JSONObject(cleanJson)
            val header = root.optJSONObject("header") ?: return@runCatching null
            val uuid = header.optString("uuid", "").ifBlank { UUID.randomUUID().toString() }
            val name = header.optString("name", fallbackName).ifBlank { fallbackName }
            val desc = header.optString("description", "")
            val ver = formatVersionArray(header.optJSONArray("version"), "1.0.0")
            val minEngine = formatVersionArray(header.optJSONArray("min_engine_version"), "")

            val modules = root.optJSONArray("modules")
            var typeRaw = ""
            if (modules != null && modules.length() > 0) {
                for (i in 0 until modules.length()) {
                    val m = modules.optJSONObject(i) ?: continue
                    val t = m.optString("type", "").lowercase()
                    if (t == "data" || t == "script" || t == "behavior") {
                        typeRaw = t
                        break
                    }
                    if (typeRaw.isEmpty() && t.isNotBlank()) {
                        typeRaw = t
                    }
                }
            }

            val packType = when (typeRaw) {
                "resources" -> AddonPackType.RESOURCE_PACK
                "data", "script", "behavior" -> AddonPackType.BEHAVIOR_PACK
                "skin_pack" -> AddonPackType.SKIN_PACK
                "world_template" -> AddonPackType.WORLD_TEMPLATE
                else -> AddonPackType.UNKNOWN
            }

            ParsedManifest(
                uuid = uuid,
                name = cleanMinecraftColorCodes(name),
                description = cleanMinecraftColorCodes(desc),
                version = ver,
                minEngineVersion = minEngine,
                type = packType
            )
        }.getOrNull()
    }

    private fun buildGlobalPackJson(uuid: String, versionStr: String): JSONObject {
        val parts = versionStr.split('.').mapNotNull { it.toIntOrNull() }
        val verArr = JSONArray().apply {
            put(parts.getOrElse(0) { 1 })
            put(parts.getOrElse(1) { 0 })
            put(parts.getOrElse(2) { 0 })
        }
        return JSONObject().apply {
            put("pack_id", uuid)
            put("version", verArr)
        }
    }

    private fun writeMetaFile(dir: File, item: InstalledAddonItem) {
        val json = JSONObject().apply {
            put("id", item.id)
            put("uuid", item.uuid)
            put("name", item.name)
            put("description", item.description)
            put("version", item.version)
            put("type", item.type.name)
            put("minEngineVersion", item.minEngineVersion)
            put("sizeBytes", item.sizeBytes)
        }
        File(dir, META_FILE).writeText(json.toString(2), Charsets.UTF_8)
    }

    private fun formatVersionArray(arr: JSONArray?, fallback: String): String {
        if (arr == null || arr.length() == 0) return fallback
        return (0 until arr.length()).map { arr.optInt(it, 0) }.joinToString(".")
    }

    private fun cleanMinecraftColorCodes(text: String): String =
        text.replace(Regex("§."), "").trim()

    private fun stripJsonComments(raw: String): String {
        return raw.lines()
            .filterNot { it.trimStart().startsWith("//") }
            .joinToString("\n")
    }

    private fun sanitizeId(raw: String): String =
        raw.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(80)

    private fun computeDirSize(dir: File): Long =
        dir.walkTopDown().filter { it.isFile && it.name != META_FILE }.sumOf { it.length() }

    private fun queryDisplayName(context: Context, uri: Uri): String? {
        val fromResolver = runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()
        return fromResolver?.takeIf { it.isNotBlank() }
            ?: uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
    }
}
