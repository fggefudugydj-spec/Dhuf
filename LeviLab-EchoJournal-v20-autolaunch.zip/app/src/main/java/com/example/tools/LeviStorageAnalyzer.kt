package com.example.tools

import android.content.Context
import com.example.model.StorageBreakdown
import java.io.File

object LeviStorageAnalyzer {

    fun collect(context: Context): StorageBreakdown {
        val filesRoot = context.filesDir
        val apkVaultBytes = dirBytes(File(filesRoot, "mc_vault"))
        val nativeCacheBytes = dirBytes(File(filesRoot, "mc_libs"))
        val addonsBytes = dirBytes(File(filesRoot, "mc_addons"))
        val modsBytes = dirBytes(File(filesRoot, "mc_mods"))
        val sandboxInternal = dirBytes(File(filesRoot, "mc_sandbox"))
        val sandboxExternal = context.getExternalFilesDir(null)?.let {
            dirBytes(File(it, "mc_sandbox"))
        } ?: 0L
        val logsBytes = dirBytes(File(filesRoot, "logs")) +
            (filesRoot.listFiles { f -> f.isFile && f.name.endsWith(".log", true) }?.sumOf { it.length() } ?: 0L)

        return StorageBreakdown(
            apkVaultBytes = apkVaultBytes,
            nativeCacheBytes = nativeCacheBytes,
            addonsBytes = addonsBytes,
            modsBytes = modsBytes,
            sandboxBytes = sandboxInternal + sandboxExternal,
            logsBytes = logsBytes
        )
    }

    private fun dirBytes(dir: File): Long {
        if (!dir.exists()) return 0L
        return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }
}
