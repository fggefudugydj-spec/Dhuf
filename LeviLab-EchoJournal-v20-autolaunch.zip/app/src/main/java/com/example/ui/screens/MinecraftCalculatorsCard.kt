package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.core.LeviStrings
import com.example.tools.MinecraftCalculators
import com.example.ui.theme.JetBrainsMonoFontFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MinecraftCalculatorsCard(
    strings: LeviStrings,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var overworldToNether by remember { mutableStateOf(true) }
    var xInput by remember { mutableStateOf("800") }
    var yInput by remember { mutableStateOf("64") }
    var zInput by remember { mutableStateOf("-400") }
    var ticksInput by remember { mutableStateOf("24000") }
    var levelInput by remember { mutableStateOf("30") }

    val x = xInput.trim().toIntOrNull() ?: 0
    val y = yInput.trim().toIntOrNull() ?: 64
    val z = zInput.trim().toIntOrNull() ?: 0

    val resultSummary: String = when (selectedTab) {
        0 -> {
            val out = if (overworldToNether) {
                MinecraftCalculators.overworldToNether(x, y, z)
            } else {
                MinecraftCalculators.netherToOverworld(x, y, z)
            }
            if (overworldToNether) {
                "Nether: X=${out.x}, Y=${out.y}, Z=${out.z}"
            } else {
                "Overworld: X=${out.x}, Y=${out.y}, Z=${out.z}"
            }
        }
        1 -> {
            val chunk = MinecraftCalculators.blockToChunkAndRegion(x, z)
            "Chunk: (${chunk.chunkX}, ${chunk.chunkZ})\nIn-Chunk: (${chunk.inChunkX}, ${chunk.inChunkZ}) [0..15]\nRegion: ${chunk.regionFileLabel}"
        }
        2 -> {
            val t = MinecraftCalculators.ticksToBedrockTime(ticksInput.trim().toLongOrNull() ?: 0L)
            "Time: ${t.formattedRealTime} (${String.format(java.util.Locale.US, "%.2f", t.seconds)}s)\nBedrock Day ${t.bedrockDays} • Tick ${t.tickOfDay}/24000\nPhase: ${t.dayPhase}"
        }
        else -> {
            val xp = MinecraftCalculators.calculateXpForLevel(levelInput.trim().toIntOrNull() ?: 0)
            "Level ${xp.level} = ${xp.totalXpRequired} Total XP\nNext level (+1): +${xp.nextLevelXpCost} XP"
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier
            .fillMaxWidth()
            .testTag("mc_calculators_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Calculate,
                    contentDescription = strings.calculatorsTitle,
                    tint = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = strings.calculatorsTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = strings.calculatorsDesc,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                FilterChip(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    label = { Text(strings.calcTabPortal) },
                    modifier = Modifier.testTag("calc_tab_portal")
                )
                FilterChip(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    label = { Text(strings.calcTabChunk) },
                    modifier = Modifier.testTag("calc_tab_chunk")
                )
                FilterChip(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    label = { Text(strings.calcTabTicks) },
                    modifier = Modifier.testTag("calc_tab_ticks")
                )
                FilterChip(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    label = { Text(strings.calcTabXp) },
                    modifier = Modifier.testTag("calc_tab_xp")
                )
            }

            when (selectedTab) {
                0, 1 -> {
                    if (selectedTab == 0) {
                        OutlinedButton(
                            onClick = { overworldToNether = !overworldToNether },
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapHoriz,
                                contentDescription = strings.calcTabPortal,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.size(6.dp))
                            Text(
                                if (overworldToNether) strings.calcOverworldToNether
                                else strings.calcNetherToOverworld
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = xInput,
                            onValueChange = { xInput = it },
                            label = { Text(strings.calcCoordXLabel) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        if (selectedTab == 0) {
                            OutlinedTextField(
                                value = yInput,
                                onValueChange = { yInput = it },
                                label = { Text(strings.calcCoordYLabel) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        OutlinedTextField(
                            value = zInput,
                            onValueChange = { zInput = it },
                            label = { Text(strings.calcCoordZLabel) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                2 -> {
                    OutlinedTextField(
                        value = ticksInput,
                        onValueChange = { ticksInput = it },
                        label = { Text(strings.calcTicksInputLabel) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                3 -> {
                    OutlinedTextField(
                        value = levelInput,
                        onValueChange = { levelInput = it },
                        label = { Text(strings.calcLevelInputLabel) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Surface(
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                shape = MaterialTheme.shapes.small,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = resultSummary,
                    style = MaterialTheme.typography.bodyMedium,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(12.dp)
                )
            }

            OutlinedButton(
                onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Minecraft Calculator", resultSummary))
                    Toast.makeText(context, strings.copiedToast, Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .testTag("calc_copy_result_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = strings.calcCopyResultButton,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.size(6.dp))
                Text(strings.calcCopyResultButton)
            }
        }
    }
}
